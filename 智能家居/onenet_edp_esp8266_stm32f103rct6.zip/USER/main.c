/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "esp8266.h"
#include "onenet.h"
#include "timer.h"

void NVIC_Config(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	 //�жϷ���2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
}

void system_init(void)
{
	NVIC_Config();
	Uart1_Init(115200);	//esp8266ͨ�Ŵ���
	Uart2_Init();//debug���Դ�ӡ����
	delay_init();
	led_init();
	esp8266_init();
	timer1_init(6000, 36000);//��ʱ3�����һ���ж�
}

int main(void)
{
  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       file (startup_stm32f10x_xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_stm32f10x.c file
     */    
	system_init();
	Connect_OneNet();

  /* Infinite loop */
  while(1){
		if(on_time){
			OneNet_SendData("Temp", rand()%100);//�ϴ�һ�����ֵ��Temp���ݵ�
			on_time=0;
		}
		esp8266_communicate_with_onenet();
		delay_ms(1000);
  }
}


