#ifndef __ESP8266_H
#define __ESP8266_H 			   

#include "stm32f10x.h"


extern char esp8266_init_done;
char esp8266_send_at(char *cmd, char * answer);
char onenet_tcp_regist(void);
char esp8266_init(void);
void esp8266_communicate_with_onenet(void);
void ESP8266_SendData(unsigned char *data, unsigned short len);

#endif





























