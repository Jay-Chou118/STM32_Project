#ifndef __USART_H
#define __USART_H 			   

#include "stm32f10x.h"

	 
extern char URecv[256];
extern volatile u16 URecv_Index; 
extern char OneNet_Connect;

void Uart1_Init(u32 baud);
void USART1_Send_Data(char *buf,u16 len);

void Uart2_Init(void);

#endif





























