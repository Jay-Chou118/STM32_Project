#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stm32f10x.h"
#include "delay.h"
#include "usart.h "
#include "led.h"
#include "esp8266.h"

//WIFI配置信息
char * WIFI_SSID = "tplink111";  //wifi名称
char * WIFI_KEY = "tttttttt";    //wifi密码

//esp8266初始化结束标识
char esp8266_init_done=0;

char esp8266_send_at(char *cmd, char * answer)
{
	char timeout = 10;
	char exec = 0;
	USART1_Send_Data(cmd, strlen((const char *)cmd));
	printf("exec cmd:%s\r\n", cmd);
	while(timeout --){
		if(URecv_Index){
			if(strstr(URecv, answer)!=NULL){			
				exec = 1;
				break;
			}			
		}
		delay_ms(100);
	}
	URecv_Index = 0;
	memset(URecv, 0, sizeof(URecv));
	if(exec){
		printf("exec at cmd ok\r\n");
		return 0;
	}else{
		printf("exec at cmd failed\r\n");
		return 1;
	}
}

char esp8266_init()
{
	char * ok = "OK";
	char * at = "AT\r\n";
  char * at_cwmode = "AT+CWMODE=1\r\n";
  char * at_rst = "AT+RST\r\n";
  char * at_cifsr = "AT+CIFSR\r\n";
  char * at_cipmux = "AT+CIPMUX=0\r\n";
  char * at_cipmode = "AT+CIPMODE=1\r\n";
  char * at_cipstart = "AT+CIPSTART=\"TCP\",\"183.230.40.39\",876\r\n";
  char * at_cipsend = "AT+CIPSEND\r\n";
	char at_cwjap[64];
	memset(at_cwjap, 0, sizeof(at_cwjap));
	strcat(at_cwjap,"AT+CWJAP=\"");
	strcat(at_cwjap,WIFI_SSID);
	strcat(at_cwjap,"\",\"");
	strcat(at_cwjap,WIFI_KEY);
	strcat(at_cwjap,"\"\r\n");
	
	USART1_Send_Data("+++", 3);//退出透传模式
	delay_ms(100);
	
  while(esp8266_send_at(at, ok)){
    delay_ms(1000);
  }
  while(esp8266_send_at(at_cwmode, ok)){
    delay_ms(1000);
  }
  while(esp8266_send_at(at_rst, ok)){
    delay_ms(1000);
  }
	delay_ms(1000);
  while(esp8266_send_at(at_cwjap, ok)){
    delay_ms(1000);
  }
  while(esp8266_send_at(at_cifsr, ok)){
    delay_ms(1000);
  }
  while(esp8266_send_at(at_cipmux, ok)){
    delay_ms(1000);
  }
  while(esp8266_send_at(at_cipmode, ok)){
    delay_ms(1000);
  }
  while(esp8266_send_at(at_cipstart, ok)){
    delay_ms(1000);
  }
  while(esp8266_send_at(at_cipsend, ok)){
    delay_ms(1000);
  }

  printf("init esp8266 done\r\n");
	esp8266_init_done =1;
	return 0;
}

void esp8266_communicate_with_onenet()
{
}


void ESP8266_SendData(unsigned char *data, unsigned short len)
{ 
	USART1_Send_Data((char *)data,len);   //发送数据
}







