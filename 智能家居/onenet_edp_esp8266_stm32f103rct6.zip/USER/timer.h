#ifndef __TIMER_H
#define __TIMER_H 			   

#include "stm32f10x.h"

void timer1_init(int arr,int psc);
extern char on_time;

#endif





























