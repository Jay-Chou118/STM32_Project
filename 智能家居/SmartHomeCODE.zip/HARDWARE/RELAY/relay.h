#ifndef __RELAY_H
#define __RELAY_H 
#include "sys.h"


//�̵���״̬
#define		Relay_ON		0
#define		Relay_OFF		1

#define RELAY PBout(9)

void RELAY_Init(void);//��ʼ��

#endif

