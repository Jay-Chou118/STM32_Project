#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h" 

#define KEY_PORT		GPIOA
#define KEY_RCC			RCC_APB2Periph_GPIOA
#define KEY_PIN			GPIO_Pin_8
#define KEY_PIN_MODE	GPIO_Mode_IPU

#define KEY  GPIO_ReadInputDataBit(KEY_PORT,KEY_PIN)//��ȡ����


void KEY_Init(void);//IO��ʼ��
				    
#endif



