#ifndef __LED_H
#define __LED_H	 
#include "stm32f10x.h"

#define LED1 PCout(13)
#define LED0 PAout(7)
void LED_Init(void);//��ʼ��
			    
#endif
