#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED0_PORT		GPIOB
#define LED0_RCC		RCC_APB2Periph_GPIOB
#define LED0_PIN		GPIO_Pin_0
#define LED0_PIN_MODE	GPIO_Mode_Out_PP

//�˿ڶ���
#define LED0 PBout(0)	// LED0, 

#define LED0_ON		1
#define LED0_OFF	0


#define LED1_PORT		GPIOC
#define LED1_RCC		RCC_APB2Periph_GPIOC
#define LED1_PIN		GPIO_Pin_13
#define LED1_PIN_MODE	GPIO_Mode_Out_PP

//�˿ڶ���
#define LED1 PCout(13)	// LED1,

#define LED1_ON		1
#define LED1_OFF	0

void LED_Init(void);	//��ʼ��


			    
#endif
