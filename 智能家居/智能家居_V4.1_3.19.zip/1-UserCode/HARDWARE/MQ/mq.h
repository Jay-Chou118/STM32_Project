#ifndef __MQ_H
#define __MQ_H

#include "adc.h"
#include "delay.h"
#include "math.h"


float mq_get_value_vrl(void);
float mq_get_value_mq2(void);
float mq_get_value_mq3(void);
float mq_get_value_mq7(void);
float mq_get_value_mq135(void);
float mq_get_value_mq136(void);

#endif
