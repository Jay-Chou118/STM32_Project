#include "uln2003.h"
#include "delay.h"

void ULN2003_Config(void)
{		
		/*定义一个GPIO_InitTypeDef类型的结构体*/
		GPIO_InitTypeDef GPIO_InitStructure;

		/*开启引脚相关的GPIO外设时钟*/
		RCC_APB2PeriphClockCmd( IN1_GPIO_CLK | IN2_GPIO_CLK | IN3_GPIO_CLK | IN4_GPIO_CLK , ENABLE);
		
	  /*选择要控制的GPIO引脚*/
		GPIO_InitStructure.GPIO_Pin = IN1_GPIO_PIN;	
		/*设置引脚模式为通用推挽输出*/
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
		/*设置引脚速率为50MHz */   
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
		/*调用库函数，初始化GPIO*/
		GPIO_Init(IN1_GPIO_PORT, &GPIO_InitStructure);	
		
		/*选择要控制的GPIO引脚*/
		GPIO_InitStructure.GPIO_Pin = IN2_GPIO_PIN;
		/*调用库函数，初始化GPIO*/
		GPIO_Init(IN2_GPIO_PORT, &GPIO_InitStructure);
		
		/*选择要控制的GPIO引脚*/
		GPIO_InitStructure.GPIO_Pin = IN3_GPIO_PIN;
		/*调用库函数，初始化GPIOF*/
		GPIO_Init(IN3_GPIO_PORT, &GPIO_InitStructure);
		
		/*选择要控制的GPIO引脚*/
		GPIO_InitStructure.GPIO_Pin = IN4_GPIO_PIN;
		/*调用库函数，初始化GPIOF*/
		GPIO_Init(IN4_GPIO_PORT, &GPIO_InitStructure);
		
		//所有引脚初始化为低电平
    IN1_LOW;
    IN2_LOW;
    IN3_LOW;
    IN4_LOW;		
}

void setDir(uint8_t dir)
{
	if(dir == FORWARD)//正转
	{
		IN1_HIGH;
		delay_ms(speed);
		IN1_LOW;
		IN2_HIGH;
		delay_ms(speed);
		IN2_LOW;
		IN3_HIGH;
		delay_ms(speed);
		IN3_LOW;
		IN4_HIGH;
		delay_ms(speed);
		IN4_LOW;
	}
	else if(dir == REVERSE)//反转
	{
		IN1_HIGH;
		delay_ms(speed);
		IN1_LOW;
		IN4_HIGH;
		delay_ms(speed);
		IN4_LOW;
		IN3_HIGH;
		delay_ms(speed);
		IN3_LOW;
		IN2_HIGH;
		delay_ms(speed);
		IN2_LOW;
	}
	else//暂停
	{
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;	
	}
}

void motor_rotate(uint8_t dir)
{
	int i;
	for(i = 0;i < 600;i++)
		setDir(dir);
}

