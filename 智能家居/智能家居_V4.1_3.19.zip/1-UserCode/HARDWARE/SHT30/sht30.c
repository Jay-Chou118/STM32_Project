#include "SHT30.h" 
#include "myiic.h"


#define write 0
#define read  1

float humiture[4];
u8 humiture_buff1[20];

 

/*******************************************************************
 温湿度获取函数               
函数原型: SHT30_read_result(u8 addr);
功能: 用来接收从器件采集并合成温湿度
********************************************************************/ 
void SHT30_read_result(float *Temperature, float *Humidity)
{
	u8 addr = 0x44;
	u16 tem,hum;
	u16 buff[6];
	*Temperature=0;
	*Humidity=0;
	
	IIC_Start();
	IIC_Send_Byte(addr<<1 | write);//写7位I2C设备地址加0作为写取位,1为读取位
	IIC_Wait_Ack();
	IIC_Send_Byte(0x2C);
	IIC_Wait_Ack();
	IIC_Send_Byte(0x06);
	IIC_Wait_Ack();
	IIC_Stop();
	delay_ms(50);
	IIC_Start();
	IIC_Send_Byte(addr<<1 | read);//写7位I2C设备地址加0作为写取位,1为读取位
	if(IIC_Wait_Ack()==0)
	{
		buff[0]=IIC_Read_Byte(1);
		buff[1]=IIC_Read_Byte(1);
		buff[2]=IIC_Read_Byte(1);
		buff[3]=IIC_Read_Byte(1);
		buff[4]=IIC_Read_Byte(1);
		buff[5]=IIC_Read_Byte(0);
		IIC_NAck();
		IIC_Stop();
	}
	
	tem = ((buff[0]<<8) | buff[1]);//温度拼接
	hum = ((buff[3]<<8) | buff[4]);//湿度拼接
	
	/*转换实际温度*/
	*Temperature= (175.0*(float)tem/65535.0-45.0) ;// T = -45 + 175 * tem / (2^16-1)
	*Humidity= (100.0*(float)hum/65535.0);// RH = hum*100 / (2^16-1)
	
	if((*Temperature>=-20)&&(*Temperature<=125)&&(*Humidity>=0)&&(*Humidity<=100))//过滤错误数据
	{
//		humiture[0]=Temperature;
//		humiture[2]=Humidity;
//		sprintf(humiture_buff1,"%6.2f*C %6.2f%%",Temperature,Humidity);//111.01*C 100.01%（保留2位小数）
	}
//	printf("温湿度：%.2f,   %.2f\r\n",*Temperature, *Humidity);
	hum=0;
	tem=0;
}


