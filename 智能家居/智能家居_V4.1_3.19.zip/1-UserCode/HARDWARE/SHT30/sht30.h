#ifndef __SHT30_H
#define __SHT30_H

#include "delay.h"
#include "sys.h"
#include "stdio.h"
#include "string.h"

extern u8 humiture_buff1[20];
void SHT30_read_result(float *Temperature, float *Humidity);
 
#endif

