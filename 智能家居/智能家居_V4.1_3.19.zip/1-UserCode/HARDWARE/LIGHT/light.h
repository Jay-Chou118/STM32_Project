#ifndef __LIGHT_H
#define __LIGHT_H
#include "stm32f10x.h"
#include "adc.h"
#include "stdio.h"
#include "math.h"
#include "delay.h"

u8 light_get_data(void);
 
#endif 


