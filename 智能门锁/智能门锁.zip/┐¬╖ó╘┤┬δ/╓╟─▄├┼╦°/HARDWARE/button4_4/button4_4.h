#ifndef _BUTTON_H 
#define _BUTTON_H
#include <sys.h>

void Button4_4_Init(void);
int Button4_4_Scan(void);



#endif

