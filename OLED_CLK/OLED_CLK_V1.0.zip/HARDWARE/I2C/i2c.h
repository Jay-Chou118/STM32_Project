//
//By   : apollo/HACKʵ����(Bվ&΢�Ź��ں�ͬ��)
//
#ifndef __I2C_H__
#define __I2C_H__

#include "stm32f10x_gpio.h"
#include "sys.h"
#include "delay.h"

#define SCL_1         GPIOB->BSRR = GPIO_Pin_6
#define SCL_0         GPIOB->BRR  = GPIO_Pin_6
   
#define SDA_1         GPIOB->BSRR = GPIO_Pin_7
#define SDA_0         GPIOB->BRR  = GPIO_Pin_7

#define SCL_read      GPIOB->IDR & GPIO_Pin_6
#define SDA_read      GPIOB->IDR & GPIO_Pin_7

void I2C_GPIO_OUT_Config(void);
void I2C_GPIO_IN_Config(void);
void I2C_Start(void);
void I2C_Stop(void);
u8   I2C_SendByte(u8 ByteData);
u8   I2C_ReceiveByte(u8 last_char);

#endif 



