#ifndef __AD7718_H
#define __AD7718_H

#include "stm32f10x.h"

//#include "stm32f10x_type.h"
#define REG_COMM			(0x00)
#define REG_STATUS		((REG_COMM) + 0)
#define REG_MODE			((REG_COMM) + 1)
#define REG_ADCCON		((REG_COMM) + 2)
#define REG_FILTER		((REG_COMM) + 3)
#define REG_ADCDATA		((REG_COMM) + 4)
#define REG_ADCOFFSET	((REG_COMM) + 5)
#define REG_ADCGAIN		((REG_COMM) + 6)
#define REG_IOCON			((REG_COMM) + 7)

#define REG_TEST			((REG_COMM) + 0x0d)
#define REG_ID				((REG_COMM) + 0x0f)

#define REG_READ_MASK        0x40
#define REG_WRITE_MASK       0x00

extern char AD_ERR;

void fBSP_SPISwitch2Att(void);
void AD_7718_Init(void);
void Init_AD_7718(void);
uint32_t AD7718_SPI_Read_REG(uint8_t REG_ADDR);
uint32_t AD7718_Read_ResultData(void);
void AD7718_SPI_Write_REG(uint8_t REG_ADDR, uint32_t Data);
uint32_t AD7718_SPI_Read_REG(uint8_t REG_ADDR);
uint8_t GET_AD_Sample(uint32_t* AD_Data);
void start_ad_sample(uint8_t Channel);
void AD_Convert_2_V(void);


#endif
