#ifndef __USER_AD_H
#define __USER_AD_H

#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"


#define MAX_AD_CHANNEL          6

extern uint8_t AD_Data_Symbol[MAX_AD_CHANNEL];
extern uint32_t AD_Data[MAX_AD_CHANNEL];
extern uint32_t AD_RemainderData[MAX_AD_CHANNEL];

extern uint8_t AD_Adjust_state[MAX_AD_CHANNEL];
extern uint32_t adjust_ad_data[2][20];
extern uint8_t adjust_count[2];

extern uint8_t AD_MAXData_Symbol[MAX_AD_CHANNEL];
extern uint32_t AD_MAXData[MAX_AD_CHANNEL];
extern uint32_t AD_MAXRemainderData[MAX_AD_CHANNEL];
extern uint8_t AD_MINData_Symbol[MAX_AD_CHANNEL];
extern uint32_t AD_MINData[MAX_AD_CHANNEL];
extern uint32_t AD_MINRemainderData[MAX_AD_CHANNEL];

extern uint8_t Set_Data_Symbol[2][MAX_AD_CHANNEL];
extern uint32_t Set_Data[2][MAX_AD_CHANNEL];
extern uint32_t Set_RemainderData[2][MAX_AD_CHANNEL];
extern uint8_t adrunstate[MAX_AD_CHANNEL];

extern void init_user_ad(void);

extern void ad_progress(void);

extern float get_now_v(void);
extern void save_data(void);

#endif

