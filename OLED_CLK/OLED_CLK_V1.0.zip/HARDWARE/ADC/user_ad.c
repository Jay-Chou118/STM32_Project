#include "user_ad.h"
#include "ad7718.h"


#define DATA_SAVE_ADDRESS    0x08030000


#define CTIMER_SELF_DEF_BASE	11
#define CTIMER_USART3_NO_BYTEIN_TIMEOUT		CTIMER_SELF_DEF_BASE
#define CTIMER_SCREEN_SAVER_JUDGE		(CTIMER_SELF_DEF_BASE+1)
#define CTIMER_SCREEN_SAVER_RUN		(CTIMER_SELF_DEF_BASE+2)
#define CTIMER_BACKLIGHT_OFF		(CTIMER_SELF_DEF_BASE+3)

#define CTIMER_KEY_HOLD		(CTIMER_SELF_DEF_BASE+4)
#define CTIMER_AD_INTERVAL		(CTIMER_SELF_DEF_BASE+5)
#define CTIMER_SCREEN_DISP		(CTIMER_SELF_DEF_BASE+6)

#define CTIMER_AD_TEMPER		(CTIMER_SELF_DEF_BASE+7)
#define CTIMER_AD_ZERO		(CTIMER_SELF_DEF_BASE+8)



uint8_t Channel,Channelbackup;
uint8_t AD_Data_Symbol[MAX_AD_CHANNEL];
uint32_t AD_Data[MAX_AD_CHANNEL];
uint32_t AD_RemainderData[MAX_AD_CHANNEL];
uint32_t AD_ZERO[MAX_AD_CHANNEL];
uint32_t AD_ZERO_dif[MAX_AD_CHANNEL];
uint32_t AD_RATIO[MAX_AD_CHANNEL];
uint32_t adjust_ad_data[2][20];
uint32_t adjust_ad_zero[20];
uint8_t adjust_count[2];
uint8_t adjust_ad_zero_count;
uint8_t AD_Adjust_state[MAX_AD_CHANNEL];

uint32_t maxmindata[MAX_AD_CHANNEL][2];
uint8_t AD_MAXData_Symbol[MAX_AD_CHANNEL];
uint32_t AD_MAXData[MAX_AD_CHANNEL];
uint32_t AD_MAXRemainderData[MAX_AD_CHANNEL];
uint8_t AD_MINData_Symbol[MAX_AD_CHANNEL];
uint32_t AD_MINData[MAX_AD_CHANNEL];
uint32_t AD_MINRemainderData[MAX_AD_CHANNEL];

uint32_t GetVGain(uint32_t v1,uint32_t v2,uint8_t inChannel);

void init_user_ad(void)
{
	uint16_t ibyte;
	Channel = 5;
	adjust_ad_zero_count = 0;
	memset(AD_Data_Symbol,2,sizeof(AD_Data_Symbol));
	memset(AD_MAXData_Symbol,2,sizeof(AD_Data_Symbol));
	memset(AD_MINData_Symbol,2,sizeof(AD_Data_Symbol));
#if 1
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
		if(AD_ZERO[ibyte]==0xffffffff)	
			AD_ZERO[ibyte] = 6724179;
		if(AD_RATIO[ibyte]==0xffffffff)	
		AD_RATIO[ibyte] = 677898;
		maxmindata[ibyte][0] = maxmindata[ibyte][1]=0xffffffff;
                if(Set_Data_Symbol[0][ibyte]==0xFF)
                  Set_Data_Symbol[0][ibyte]=0;
		if(Set_Data[0][ibyte]==0xffffffff)	
                Set_Data[0][ibyte] = 1;
                if(Set_RemainderData[0][ibyte]==0xffffffff)
                  Set_RemainderData[0][ibyte] = 0 ;
                 if(Set_Data_Symbol[1][ibyte]==0xFF)
                  Set_Data_Symbol[1][ibyte]=0;
		if(Set_Data[1][ibyte]==0xffffffff)	
               Set_Data[1][ibyte] = 0;
                if(Set_RemainderData[1][ibyte]==0xffffffff)
                  Set_RemainderData[1][ibyte] = 0 ;
		if(adrunstate[ibyte]==0xff)
		{
			adrunstate[ibyte] = 0;
			if((ibyte==2)||(ibyte==3))
				adrunstate[ibyte] = 1;
		}
	}
#endif
}
void ad_progress(void)
{
	static uint8_t first_run=0;
	uint8_t adstate;
	static uint32_t getADdata,getADdata_back;
        float floatdata;
	static uint8_t ad_progress_state = 0;
	static uint8_t ad_count[MAX_AD_CHANNEL] ;
	uint8_t ibyte;
 //       if (CwxTimerCheckTimeOut(CTIMER_AD_INTERVAL)==1)
 	if(ad_progress_state==0)
        {
	        adstate = GET_AD_Sample(&getADdata);
	        if(adstate)
	        {
	        	for(ibyte=0;ibyte<5;ibyte++)
	        	{
		        	if(AD_Adjust_state[ibyte] == 1)
		        	{
		        		Channel = ibyte;
			        	Channelbackup = Channel;
                                adjust_count[0]=0;
                                break;
		        	}
	        	}
			// 1-5Ϊ����У׼��ȡԭʼֵ
			switch(AD_Adjust_state[Channelbackup])
			{
			case 2:
				if((getADdata&0xf00000) != 0xf00000)
				{
					if(adjust_count[0]<20)
						adjust_ad_data[0][adjust_count[0]++] = getADdata;
					else
					{
						AD_Adjust_state[Channelbackup] = 4;
						adjust_count[1]=0;
						Channel = 5;
					}
				}
				break;
			case 4:
				if((getADdata&0xf00000) != 0xf00000)
				{
					if(adjust_count[1]<20)
						adjust_ad_data[1][adjust_count[1]++] = getADdata;
					else
					{
						AD_Adjust_state[Channelbackup] = 5;
					}
				}
				break;
			case 5:
				getADdata = 0 ;
				getADdata_back = 0 ;
				for(uint8_t ibyte=0;ibyte<20;ibyte++)
				{
					getADdata += adjust_ad_data[0][ibyte];
					getADdata_back += adjust_ad_data[1][ibyte];
				}
				getADdata /= 20 ;
				getADdata_back /= 20 ;
				AD_ZERO_dif[Channelbackup] = getADdata_back-getADdata;
				AD_Adjust_state[Channelbackup] = 6;
                                save_data();
				break;
			case 3:
				if((getADdata&0xf00000) != 0xf00000)
				{
					if(adjust_count[1]<20)
						adjust_ad_data[1][adjust_count[1]++] = getADdata;
				}
				break;
			case 1:
				break;
			default:
				if(((getADdata&0xf00000) != 0xf00000)&&(Channel==5))
				{
					//�ɼ�0V��׼
					ad_count[Channel]=0;
					if(first_run>4)
					{
						adjust_ad_zero[adjust_ad_zero_count++%20] = getADdata;
						if(adjust_ad_zero_count>40)
						{
							adjust_ad_zero_count = 20;
						}
						getADdata = 0;
						if(adjust_ad_zero_count>=20)
						{
					        	for(ibyte=0;ibyte<20;ibyte++)
					        	{
					        		getADdata +=adjust_ad_zero[ibyte];
					        	}
							getADdata /= 20 ;
						}
						else
						{
					        	for(ibyte=0;ibyte<adjust_ad_zero_count;ibyte++)
					        	{
					        		getADdata +=adjust_ad_zero[ibyte];
					        	}
							getADdata /= adjust_ad_zero_count ;
						}
						AD_ZERO[0] = getADdata-AD_ZERO_dif[0];
						AD_ZERO[1] = getADdata-AD_ZERO_dif[1];
						AD_ZERO[2] = getADdata-AD_ZERO_dif[2];
						AD_ZERO[3] = getADdata-AD_ZERO_dif[3];
						AD_ZERO[4] = getADdata-AD_ZERO_dif[4];
					}
					else
						first_run++;
				}
				else if(((getADdata&0xf00000) != 0xf00000)&&(adrunstate[Channel]))
				{
					//�ɼ�1-5·ADֵ
                                        getADdata_back = getADdata;
					ad_count[Channel]=0;
					if((maxmindata[Channel][0] ==0xffffffff)||(AD_MAXData_Symbol[Channel]==2))
					{
						maxmindata[Channel][0] = getADdata;
					}
					if((maxmindata[Channel][1]==0xffffffff)||(AD_MINData_Symbol[Channel]==2))
					{
						maxmindata[Channel][1] = getADdata;
					}
					if(getADdata>AD_ZERO[Channel])
			        	{
			        		AD_Data[Channel] = (getADdata-AD_ZERO[Channel])/AD_RATIO[Channel];
						getADdata = (getADdata-AD_ZERO[Channel])%AD_RATIO[Channel];
#if 1
                                                floatdata = getADdata;
                                                floatdata = floatdata/AD_RATIO[Channel];
						AD_RemainderData[Channel] = floatdata*10000;//
#endif
//                                                AD_RemainderData[Channel] = (getADdata*10000)/AD_RATIO[Channel];
						AD_Data_Symbol[Channel] = 0;
			        	}
					else
					{
			        		AD_Data[Channel] = (AD_ZERO[Channel]-getADdata)/AD_RATIO[Channel];
						getADdata = (AD_ZERO[Channel]-getADdata)%AD_RATIO[Channel];
#if 1
                                                floatdata = getADdata;
                                                floatdata = floatdata/AD_RATIO[Channel];
						AD_RemainderData[Channel] = floatdata*10000;//
#endif
//						AD_RemainderData[Channel] = (getADdata*10000)/AD_RATIO[Channel];
						AD_Data_Symbol[Channel] = 1;
					}
					if(maxmindata[Channel][0]<=getADdata_back)
					{
                                          maxmindata[Channel][0]=getADdata_back;
						AD_MAXData_Symbol[Channel] = AD_Data_Symbol[Channel];
						AD_MAXData[Channel] = AD_Data[Channel];
						AD_MAXRemainderData[Channel] = AD_RemainderData[Channel] ;
					}
					if(maxmindata[Channel][1]>=getADdata_back)
					{
                                          maxmindata[Channel][1]=getADdata_back;
						AD_MINData_Symbol[Channel] = AD_Data_Symbol[Channel];
						AD_MINData[Channel] = AD_Data[Channel];
						AD_MINRemainderData[Channel] = AD_RemainderData[Channel] ;
					}
				}
				else
				{
					if(ad_count[Channel]++>10)
						AD_Data_Symbol[Channel] = 2;
					else
					{
						CwxTimerClrTimeOut(CTIMER_AD_INTERVAL);
						CwxTimerStart(CTIMER_AD_INTERVAL);
						return;
					}
//						AD_MAXData_Symbol[Channel] =2;
//						AD_MINData_Symbol[Channel] =2;
				}
#if 1
				uint8_t ad_temper;
				ad_temper = 1;
				if(CwxTimerCheckTimeOut(CTIMER_AD_ZERO)==1)
				{
					//�ɼ�0V��׼
						CwxTimerClrTimeOut(CTIMER_AD_ZERO);
						CwxTimerStart(CTIMER_AD_ZERO);
						Channel = 5;
				}
				else
				{
					if(adjust_ad_zero_count<20)
					{
						Channel = 5;
					}
					else
					{
						if(CwxTimerCheckTimeOut(CTIMER_AD_TEMPER)==1)
						{
						//�ɼ��¶�
							CwxTimerClrTimeOut(CTIMER_AD_TEMPER);
							CwxTimerStart(CTIMER_AD_TEMPER);
							if(adrunstate[4])
							{
								ad_temper = 0;
								Channel = 4;
							}
						}
						if(ad_temper)
						{
							//������ʾҳ��ɼ�����
							switch(get_pagenumA())
							{
							case 0:
								for(uint8_t i=Channel+1;i<=3+Channel;i++)
								{
									if(adrunstate[i%3])
									{
										Channel = i%3 ;
										break;
									}
								}
								CwxTimerInit(CTIMER_AD_INTERVAL,5,0,0);
								break;
							case 1:
								if(adrunstate[0])
								{
									Channel = 0;
								}
	//							CwxTimerInit(CTIMER_AD_INTERVAL,10,0,0);
								break;
							case 2:
								if(adrunstate[1])
								{
									Channel = 1;
								}
								CwxTimerInit(CTIMER_AD_INTERVAL,10,0,0);
								break;
							case 3:
								if(adrunstate[2])
								{
									Channel = 2;
								}
	//							CwxTimerInit(CTIMER_AD_INTERVAL,10,0,0);
								break;
							case 4:
								if(adrunstate[3])
								{
									Channel = 3;
								}
	//							CwxTimerInit(CTIMER_AD_INTERVAL,10,0,0);
								break;
							}
						}
					}
				}
#elif 0
				for(Z1UINT8 i=Channel+1;i<=MAX_AD_CHANNEL+Channel;i++)
				{
					if(adrunstate[i%MAX_AD_CHANNEL])
					{
						Channel = i%MAX_AD_CHANNEL ;
						break;
					}
				}
#else
				Channel++;
				if(Channel>=5)
					Channel = 0;
#endif
				break;
			}
#if 1
                        start_ad_sample(Channel);
#else
			ad_progress_state = 1;
			CwxTimerClrTimeOut(CTIMER_AD_INTERVAL);
			CwxTimerStart(CTIMER_AD_INTERVAL);
#endif
                }
	}
#if 0
	if((ad_progress_state)&&(CwxTimerCheckTimeOut(CTIMER_AD_INTERVAL)==1))
	{
		ad_progress_state = 0;
		start_ad_sample(Channel);

	}
#endif
}

void AD_djust_Gain(uint8_t inChannel)
{
	uint8_t ibyte;
	uint32_t ad_data[2];
	ad_data[0] = adjust_ad_data[0][0];
	ad_data[1] = adjust_ad_data[1][0];
	for(ibyte=1;ibyte<20;ibyte++)
	{
		if(ibyte<adjust_count[0])
			ad_data[0] = (ad_data[0]+adjust_ad_data[0][0])/2;
		if(ibyte<adjust_count[1])
			ad_data[1] = (ad_data[1]+adjust_ad_data[1][0])/2;
	}
	AD_ZERO[inChannel] = ad_data[0] ;
	AD_RATIO[inChannel] = GetVGain(ad_data[1],ad_data[0],inChannel);
}

#if 1
uint32_t GetVGain(uint32_t v1,uint32_t v2,uint8_t inChannel)
{
	uint32_t now_v;
	float user_v,getv;
	if(v2>v1)
	{
		user_v = v2 - v1 ;
	}
	else
	{
		user_v = v1 - v2 ;
	}
        getv = get_now_v();
	user_v /= getv;
	now_v = user_v ;
	return now_v;
}
#endif

void save_data(void)
{
	uint32_t _RamSource_;
	uint32_t _FlashDestination_;
	uint16_t ibyte;
	FLASH_Unlock();
	FLASH_ErasePage(DATA_SAVE_ADDRESS);
	_FlashDestination_ = DATA_SAVE_ADDRESS;
	_RamSource_ = (uint32_t)(&(AD_ZERO[0]));
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
		FLASH_ProgramWord(_FlashDestination_, *(uint32_t*)_RamSource_);
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(AD_RATIO[0]));
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
		FLASH_ProgramWord(_FlashDestination_, *(uint32_t*)_RamSource_);
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(Set_Data_Symbol[0][0]));
	for(ibyte=0;ibyte<2*MAX_AD_CHANNEL;ibyte++)
	{
		FLASH_ProgramWord(_FlashDestination_, *(uint32_t*)_RamSource_);
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(Set_Data[0][0]));
	for(ibyte=0;ibyte<2*MAX_AD_CHANNEL;ibyte++)
	{
		FLASH_ProgramWord(_FlashDestination_, *(uint32_t*)_RamSource_);
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(Set_RemainderData[0][0]));
	for(ibyte=0;ibyte<2*MAX_AD_CHANNEL;ibyte++)
	{
		FLASH_ProgramWord(_FlashDestination_, *(uint32_t*)_RamSource_);
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(adrunstate[0]));
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
                if(adrunstate[ibyte]==0)
                {
                     AD_Data_Symbol[ibyte]=2;
                   AD_MINData_Symbol[ibyte]=2;
                    AD_MAXData_Symbol[ibyte]=2;
                }
		FLASH_ProgramWord(_FlashDestination_, *(uint32_t*)_RamSource_);
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(AD_ZERO_dif[0]));
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
		FLASH_ProgramWord(_FlashDestination_, *(uint32_t*)_RamSource_);
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
}

void read_data(void)
{
	uint32_t _RamSource_;
	uint32_t _FlashDestination_;
	uint16_t ibyte;
	FLASH_Unlock();
//	FLASH_ErasePage(DATA_SAVE_ADDRESS);
	_FlashDestination_ = DATA_SAVE_ADDRESS;
	_RamSource_ = (uint32_t)(&(AD_ZERO[0]));
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
		(*(uint32_t*)_RamSource_) = *(uint32_t*)_FlashDestination_;
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(AD_RATIO[0]));
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
		(*(uint32_t*)_RamSource_) = *(uint32_t*)_FlashDestination_;
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(Set_Data_Symbol[0][0]));
	for(ibyte=0;ibyte<2*MAX_AD_CHANNEL;ibyte++)
	{
		(*(uint32_t*)_RamSource_) = *(uint32_t*)_FlashDestination_;
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(Set_Data[0][0]));
	for(ibyte=0;ibyte<2*MAX_AD_CHANNEL;ibyte++)
	{
		(*(uint32_t*)_RamSource_) = *(uint32_t*)_FlashDestination_;
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(Set_RemainderData[0][0]));
	for(ibyte=0;ibyte<2*MAX_AD_CHANNEL;ibyte++)
	{
		(*(uint32_t*)_RamSource_) = *(uint32_t*)_FlashDestination_;
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(adrunstate[0]));
	for(ibyte=0;ibyte<2;ibyte++)
	{
		(*(uint32_t*)_RamSource_) = *(uint32_t*)_FlashDestination_;
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
	_RamSource_ = (uint32_t)(&(AD_ZERO_dif[0]));
	for(ibyte=0;ibyte<MAX_AD_CHANNEL;ibyte++)
	{
		(*(uint32_t*)_RamSource_) = *(uint32_t*)_FlashDestination_;
		_FlashDestination_ += 4;
		_RamSource_ += 4;
	}
}
