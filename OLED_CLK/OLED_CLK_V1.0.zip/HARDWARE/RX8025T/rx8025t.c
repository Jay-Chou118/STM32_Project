//
//By   : apollo/HACKʵ����(Bվ&΢�Ź��ں�ͬ��)
//
#include "rx8025t.h"
#include "string.h"
#include "stdio.h"
#include "time.h"
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"

STDATETIME      stDateTime;
SPECIALFLAG     specialFlag;
DEVSTATE        devState;
u8              pubRam[32];

//BCD��ת��λʮ����
u8 BCD2DEC(u8 temp)
{
  temp = (temp >> 4) * 10 + (temp & 0x0f);
  return temp;
}

//��λʮ����תBCD��
u8 DEC2BCD(u8 temp)
{
  temp = (temp / 10) * 16 + (temp % 10);
  return temp;
}


void Get8025( u8 addr, u8 *data,u8 counter)
{ 
    u8 i;
    I2C_Start();
    I2C_SendByte(0x64);
    I2C_SendByte(addr);
    I2C_Start();
    I2C_SendByte(0x65);
    for (i = 0;  i < counter - 1 ;  i++)
      *data++ = I2C_ReceiveByte(0);
    *data++ = I2C_ReceiveByte(1);
    I2C_Stop();
} 

int8_t Get8025_sec(void)
{ 
    u8 t_buf[1];	  
    Get8025(RTC8025_Second, t_buf, 1);   //Timebuf������ΪBCD��
	  t_buf[0] = BCD2DEC(t_buf[0]);	
	  return t_buf[0];
}

int8_t Get8025_min(void)
{ 
    u8 t_buf[1];	  
    Get8025(RTC8025_Minute, t_buf, 1);   //Timebuf������ΪBCD��
	  t_buf[0] = BCD2DEC(t_buf[0]);	
	  return t_buf[0];
}

void Set8025( u8 addr, u8 *data,u8 counter)
{ 
   u8 i;
   I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(addr);
   for(i = 0; i <counter; i++) 
     I2C_SendByte(*data++);
   I2C_Stop();
}

//�뵥������
void Set8025_sec(u8 sec)
{
   u8 temp=0;
   temp=DEC2BCD(sec);
	 I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(0x00);
   I2C_SendByte(temp);
   I2C_Stop();
}

//�ֵ�������
void Set8025_min(u8 min)
{
   u8 temp=0;
	 temp=DEC2BCD(min);
	 I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(0x01);
   I2C_SendByte(temp);
   I2C_Stop();
}

//ʱ��������
void Set8025_hour(u8 hour)
{
   u8 temp=0;
	 temp=DEC2BCD(hour);
	 I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(0x02);
   I2C_SendByte(temp);
   I2C_Stop();
}

//���ڵ�������
void Set8025_week(u8 week)
{
   u8 temp=0;
	
	 if(week == 7)
      week = 0x01;
   else if(week == 1)
      week = 0x02;
   else if(week == 2)
      week = 0x04;
   else if(week == 3)
      week = 0x08;
   else if(week == 4)
      week = 0x10;
   else if(week == 5)
      week = 0x20;
   else if(week == 6)
      week = 0x40;
	 
	 temp=week;
	 I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(0x03);
   I2C_SendByte(temp);
   I2C_Stop();
}

//�յ�������
void Set8025_day(u8 day)
{
   u8 temp=0;
	 temp=DEC2BCD(day);
	 I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(0x04);
   I2C_SendByte(temp);
   I2C_Stop();
}

//�µ�������
void Set8025_month(u8 month)
{
   u8 temp=0;
	 temp=DEC2BCD(month);
	 I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(0x05);
   I2C_SendByte(temp);
   I2C_Stop();
}

//�굥������
void Set8025_year(u8 year)
{
   u8 temp=0;
	 temp=DEC2BCD(year);
	 I2C_Start();
   I2C_SendByte(0x64);
   I2C_SendByte(0x06);
   I2C_SendByte(temp);
   I2C_Stop();
}


void Init8025(void)
{   
    u8 da[3];
    da[0]=0x00;
    da[1]=0x00;         // 24Сʱģʽ����,1Hz  Ƶ�����
    da[2]=0x60;
	
	
	
	 	GPIO_InitTypeDef  GPIO_InitStructure;
	
 	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��E�˿�ʱ��
	
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;	 //PB6
 	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
 	  GPIO_Init(GPIOB, &GPIO_InitStructure);	  //��ʼ��PE4,PE6
 	  GPIO_SetBits(GPIOB,GPIO_Pin_6);	//PE4,PE6,PE1�����
	
    Set8025(RTC8025T_Control1,da,3);
    memset(pubRam,0,3);
    Get8025(RTC8025T_Control1,pubRam,3);
    
    if(pubRam[2] != da[2])
    {
      specialFlag.I2C8025F = 1;
    }
    else
    {
      specialFlag.I2C8025F = 0;
    }
}  

void TimerDataHandle(u8* pDate)
{
    stDateTime.second = BCD2DEC(pDate[0]);   
    stDateTime.minute = BCD2DEC(pDate[1]);
    
    if(pDate[2]==0x24)
        pDate[2] = 0;
    stDateTime.hour = BCD2DEC(pDate[2]);
    
    if(pDate[3] == 0x01)
        stDateTime.week = 7;
    else if(pDate[3] == 0x02)
        stDateTime.week = 1;
    else if(pDate[3] == 0x04)
        stDateTime.week = 2;
    else if(pDate[3] == 0x08)
        stDateTime.week = 3;
    else if(pDate[3] == 0x10)
        stDateTime.week = 4;
    else if(pDate[3] == 0x20)
        stDateTime.week = 5;
    else if(pDate[3] == 0x40)
        stDateTime.week = 6;
    
    stDateTime.date  = BCD2DEC(pDate[4]);
    stDateTime.month = BCD2DEC(pDate[5]);
    stDateTime.year  = BCD2DEC(pDate[6]);
}

void RtcSetDateTime(STDATETIME *pTime)
{
   u8 Timebuf[7];
   
   Timebuf[0] = DEC2BCD(pTime->second);
   Timebuf[1] = DEC2BCD(pTime->minute);
   Timebuf[2] = DEC2BCD(pTime->hour);
   Timebuf[3] = (0x01)<<(pTime->week);  
   Timebuf[4] = DEC2BCD(pTime->date);
   Timebuf[5] = DEC2BCD(pTime->month);
   Timebuf[6] = DEC2BCD(pTime->year);
   
   Set8025(0,Timebuf,7);   //Timebuf������ΪBCD��
   TimerDataHandle(Timebuf);
}
  
void RtcSetLocalTime()
{  
  struct    tm *now_ptm;
  time_t     timep;
  STDATETIME set_time;                      //������ʱ���붼��BCD��
	time_t time(time_t *);
    
  //timep = time(NULL);                       //��ȡ��ǰRTCʱ���
  timep += 8 * 3600;                        //RTCʱ���ת���ɱ���ʱ���ʱ���  
  now_ptm = gmtime(&timep);                 //ָ��ָ��ṹ��������Ϊʮ����
  set_time.second  = now_ptm->tm_sec;       //ȡֵ����Ϊ[0,59]
  set_time.minute  = now_ptm->tm_min;       //ȡֵ����Ϊ[0,59]
  set_time.hour    = now_ptm->tm_hour;      //ȡֵ����Ϊ[0,23]
  set_time.week    = now_ptm->tm_wday;      //ȡֵ����Ϊ[0,6]��0Ϊ������
  set_time.date    = now_ptm->tm_mday;      //ȡֵ����Ϊ[1,31]
  set_time.month   = now_ptm->tm_mon + 1;   //ȡֵ����Ϊ[0,11] ��0Ϊ1��
  set_time.year    = now_ptm->tm_year - 100;//tm�����1900��ʼ����
  set_time.reserve = 0;  
  
  RtcSetDateTime(&set_time);
}

void UpdateDateTime()
{
    u8 Timebuf[7];
    
    Get8025(RTC8025_Second, Timebuf, 7);   //Timebuf������ΪBCD��
    TimerDataHandle(Timebuf);
}

