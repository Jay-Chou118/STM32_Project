//=======================
//ȫ�����ݶ���
//=======================
 
#ifndef __GLOBAL_DATA_H__
#define __GLOBAL_DATA_H__

#include "stdint.h"
#include "stm32f10x.h"

#define u8 uint8_t
#define u16 uint16_t
#define u32 uint32_t


typedef struct
{
  char second;
  char minute;
  char hour;  
  char week;
  char date;   
  char month;
  char year;
  char reserve;
}STDATETIME;

typedef struct
{  
   u8 minute;
   u8 hour;  
   u8 date;   
   u8 month;
   u8 year;
}DATETIME_ST; 

typedef struct
{
   u8 minute;
   u8 hour;  
   u8 date;   
   u8 month;
   u8 year;
   u8 m_d;
   u8 m_n;
   u8 reserve;
}FREEZE_TIME;

typedef struct                   
{ 
  u16 DataMinuteValid:   1;
  u16 MinuteForSampleAve:1;
  
  u16 I2C32F:1;           //AT24C32�洢���Լ����
  u16 I2C8025F:1;         //8563ʱ���Լ����
  u16 FSMCNANDF:1;        //NAND�Լ����
  u16 SPI3180F:1;         //MAX3180
  u16 USB376F:1;          //USBоƬ�Լ����
  u16 NetChip:1;
  u16 GPRScom_finish:1;
  u16 GPRSTxf:1;
  u16 GPRSLoginStart:1;
  u16 GPRSLoginEnd:1;
  u16 ReadFromGprs:1;
  u16 SendTxforGpsr:1;
  u16 SendLoginTxt:2;      //1-��½2-����
  u16 FirstSet:1;
  u16 SavePowDDU:1;
  u16 InitYX:1;
  u16 HasEventFlag:1;
  u16 doOneKeyConfirm:1;
  u16 YK_Recordf:2;          //��ң�ؼ�¼
  u16 SendSMS:2;
  u16 CalledNum:3;           //���Ŵ���
  u16 cycle_Dis:4;
  u16 cycle_time:3;
  u16 MonthInitNeed:1;
  u16 IfEsamCheckOn:1;
  u16 IfEthernetON:1;
  u16 IfEthHasInited:1;
  u16 EthernetInit:1;
  u16 Shellmode :1;
  u16 LocalShell:1;
  u16 WifiFrom:1;
  u16 LocalFrom:1;
  u16 pt104mode:1;
  u16 Hasaddr:1;
  u16 res:2;
  
}SPECIALFLAG;

typedef struct   
{ 
  u16 stop_cleardg:1;        //ͣι���Ź� 
  
  u16 NowTimePeriod:2;
  u16 HasPower:1;
  
  u16 KeyDownFlag:1;
  u16 SecondFlag:1;        //���־
  u16 MinuteFlag:1;
  
  u16 DataRx:1;
  u16 DataTx:1;
  
  u16 n10ms_Flag:1;
  u16 n50msFlag:1;
  u16 AutoUp:1;
  u16 EventUp:1;
  u8 wirelessMode;
  u8 ShowERC1;
  u8 ShowERC2;
 
}DEVSTATE; 

typedef struct
{ 
   u8 minute;
   u8 hour;  
   u8 date;  
   u8 month;
}SMHD_ST;

typedef struct
{
 u16    Losscnt;
 u32    Runtime;
 SMHD_ST BeginTime;
 SMHD_ST EndTime; 
}PHASELOSS_ST;

typedef struct
{
  u16 UCrossHH:1;
  u16 UCrossH:1;
  u16 UCrossL:1;
  u16 UCrossLL:1;
  u16 ULost:1;
  
  u16 ICrossHH:1;
  u16 ICrossH:1;
  
  u16 ULoss:1;
  u16 UPhaseLoss:1;
  u16 IShort:1;
  u16 IOpen:1;
  u16 IRever:1;
  
  u16 reserve:1;
}YUEX_STRUCT;

typedef struct
{
  u8  CompareAddNo;
  u8  ReferAddNo;
  u8  Comparetype ;
  u8  RelatDDuVal ;
  u32 AbsolDDuVal ;
  u32 Cddu;
  u32 Rddu;
  u16  Newchadongflag:1;
  u16  Oldchadongflag:1;
}DDUCHADON_ST;
extern DDUCHADON_ST DDUchadonST[];

//���ɹ��������Լ
typedef struct          // 1 byte
{
   u16  FUNC:4;
   u16  REV:1;
   u16  ACD:1;
   u16  PRM:1;
   u16  DIR:1;
}CONTROL_FEILD;         //������

typedef struct
{
   u16 A1;
   u16 A2;
   u8 A3;
}ADDRESS_FEILD;         //��ַ��

typedef struct
{
   u8  A0;
   u8  A1;
   u8  A2;            //�ն˳������
   u8  Factory;
   u8  Out_year;
   u8  Version;
}ADDRESS;

typedef struct
{ 
   u16 RSEQ:4;      //��Ӧ֡���
   u16 CON:1;       //����ȷ�ϱ�־
   u16 FIN:1;       //ĩ֡��־
   u16 FIR:1;       //��֡��־
   u16 TpV:1;       //֡ʱ���ǩ��Чλ  
}SEQ_FEILD;              //֡������

typedef struct
{
   u8     DA1;
   u8     DA2;
   u8     DT1;
   u8     DT2;
}DATA_UNIT_ID;           //���ݵ�Ԫ��ʶ

typedef struct
{
   u8 EC1;
   u8 EC2;
}EC_COUNTER;             //�¼�������

typedef struct
{
   u16 DF:2;        //��Լ��ʶ
   u16 L1:14;       //�û����ݳ���
}LEN_STRUCT;

typedef struct
{
   u8 PFC;             //����֡��ż�����
   u8 nSecond;         //��
   u8 nMinute;         //��
   u8 nHour;           //ʱ
   u8 nDate;           //��
   u8 nDelay;          //����������ʱ
}TIME_P;       

typedef struct 
{  u8 minute;
   u8 hour;
   u8 date;
}MHD_TIME_ST;


typedef struct
{  u8 date;
   u8 month;
   u8 year;
}DMY_TIME_ST;

typedef struct
{  u32 ZlostVTime;   //��ʧѹʱ��
   u32 AlostVTime;   //A��ʧѹʱ��
   u32 BlostVTime;   //B��ʧѹʱ��
   u32 ClostVTime;   //C��ʧѹʱ��
}ULOSTVTIME_ST;

typedef struct
{  u8 state;
   u8 changed;
}YX_STATE_ST;

typedef struct
{
   u8 IP[4];    //IP��ַ
   u16 CommNum;  //�˿ں�
}IPCONSTRUCT;

typedef struct
{
   IPCONSTRUCT  main_IP;
   IPCONSTRUCT  reserve_IP;
   char APN[16];          //APN
}GPRSCOMSET;             //GPRSģ��״̬

typedef struct
{
   char  CardName[32];
   char  CardPassword[32];
}CDMAUSERCARD;

typedef struct
{
  u8 Commandtype;      //AT+i��������
  u8 Commandlen;       //AT+i�����볤��
}ATCOMMAMD;


typedef struct
{
   s16 Ua_angle;
   s16 Ub_angle;
   s16 Uc_angle;
   
   s16 Ia_angle;
   s16 Ib_angle;
   s16 Ic_angle;
   
   s16 Uo;
   s16 Io;
}PHASEANDZERO;

typedef struct
{
   DATETIME_ST   RecTime;
   PHASEANDZERO  PhaseAndZero;
}HISPAHSEANDZERO;



#define HARMONIC_NUM 19

typedef struct            
{
  u16   AlarmVaildFlag:1;
  u16   AlarmStartFlag:1;
  u16   AlarmIngFlag:1;
  u16   cnt:8;
  u16   nums:8;
  u16   idledelay:8;
  u16   ringdelay:8;
}ALARM_STRUCT;

#endif

