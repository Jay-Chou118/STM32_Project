
//By   : apollo/HACKʵ����(Bվ&΢�Ź��ں�ͬ��)

#include "gpio.h"

//=============================
// GPIO���ú���
//=============================

void Gpio_Config(GPIO_TypeDef* GPIOx,u16 Pin_BIT,GPIOMode_TypeDef Mode)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    GPIO_InitStructure.GPIO_Pin =  Pin_BIT;
    GPIO_InitStructure.GPIO_Mode = Mode;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    
    GPIO_Init(GPIOx, &GPIO_InitStructure);
}

void E2P_GPIO_Init(void)
{
    Gpio_Config(GPIOB, BIT1+BIT10, DIR_OUT);//SCL B10 SDA B11
    GPIOB->BSRR = GPIO_Pin_1;              //WP  �ø���Ϊд���� B1
}

void LED_GPIO_Init(void)
{
    Gpio_Config(GPIOA, BIT5+BIT6, DIR_OUT);
}

void USART1_GPIO_Init(void)     //USART1
{
    Gpio_Config(GPIOA,BIT9,GPIO_Mode_AF_PP);        //TXD����
    Gpio_Config(GPIOA,BIT10,GPIO_Mode_IN_FLOATING); //RXD����
}

void USART2_GPIO_Init(void)   //USART2
{
    Gpio_Config(GPIOA,BIT2,GPIO_Mode_AF_PP);       //TXD����
    Gpio_Config(GPIOA,BIT3,GPIO_Mode_IN_FLOATING); //RXD����
}

void USART_GPIO_Init(void)
{
    USART1_GPIO_Init();//USART1  485
    USART2_GPIO_Init();//USART2  232
}

void WDI_GPIO_Init(void)
{
    Gpio_Config(GPIOB,BIT0,GPIO_Mode_Out_PP); //WDI  PE1
}

void KEY_GPIO_Init(void)
{
    Gpio_Config(GPIOA, BIT15, DIR_INT);//CANCEL
    Gpio_Config(GPIOC, BIT10+BIT11+BIT12, DIR_INT);//ENTER UP DOWN
}

void YK_GPIO_Init(void)
{
    Gpio_Config(GPIOB, BIT4+BIT5+BIT6+BIT7+BIT8+BIT9, DIR_OUT);
    Gpio_Config(GPIOE, BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT6, DIR_OUT);
    Gpio_Config(GPIOC, BIT13+BIT14+BIT15, DIR_OUT);
}

void CAN_GPIO_Init(void)
{
    return;
}

void GPIO_Configuration()
{ 
    E2P_GPIO_Init();
    LED_GPIO_Init();
    USART_GPIO_Init();
    WDI_GPIO_Init();
    KEY_GPIO_Init();
    YK_GPIO_Init();
    CAN_GPIO_Init();
}
