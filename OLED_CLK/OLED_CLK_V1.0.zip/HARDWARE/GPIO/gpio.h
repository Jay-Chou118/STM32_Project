#ifndef __GPIO_H__
#define __GPIO_H__

#include "includes.h"

#define  BIT0 GPIO_Pin_0
#define  BIT1 GPIO_Pin_1
#define  BIT2 GPIO_Pin_2
#define  BIT3 GPIO_Pin_3
#define  BIT4 GPIO_Pin_4
#define  BIT5 GPIO_Pin_5 
#define  BIT6 GPIO_Pin_6
#define  BIT7 GPIO_Pin_7
#define  BIT8 GPIO_Pin_8
#define  BIT9 GPIO_Pin_9
#define  BIT10 GPIO_Pin_10
#define  BIT11 GPIO_Pin_11
#define  BIT12 GPIO_Pin_12
#define  BIT13 GPIO_Pin_13
#define  BIT14 GPIO_Pin_14
#define  BIT15 GPIO_Pin_15

#define DIR_OUT    GPIO_Mode_Out_PP
#define DIR_INT    GPIO_Mode_IPU

void GPIO_Configuration(void);

#endif

