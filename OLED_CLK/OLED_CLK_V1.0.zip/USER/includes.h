#ifndef _MY_H
#define _MY_H

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#include "stm32f10x.h"
#include "misc.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_rtc.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_flash.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_fsmc.h"
#include "stm32f10x_i2c.h"

typedef enum {false = 0, true = !false} bool;

#endif

