/*
**************************************************************************************************
*                                MCU: STM32F103 RET6 - 64Pin
*                                OSC: 8.000MHz(external)
*                                BUS: 72.0MHz
* File : main.c
* By   : apollo/HACKʵ����(Bվ&΢�Ź��ں�ͬ��)
**************************************************************************************************
*/
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "oled.h"
#include "exti.h"
#include "rx8025t.h" 
#include "stdio.h"
#include "key.h"
#include "ad7718.h"
#include "stdlib.h"
#include "iwdg.h"
#include "flash.h"
#include "adc.h"

#define BIN2BCD(x)   ((((x/10)<<4)&0xf0) |((x%10)&0x0f) )
#define BCD2BIN(x)   ((((x>>4)&0x0f)*10)+(x&0x0f))

extern STDATETIME stDateTime;
extern u8 USART3_RX_STA;
extern u8 USART3_RX_BUF[100];     //���ջ���,���USART_REC_LEN���ֽ�.
extern u8 USART3_Counter;

unsigned char time_set;

STDATETIME setdate_buf;

void data_trans(void);
	
typedef struct
{
	char   second;   // 00~59
	char   minute;   // 00~59
	char   hour;     // 00~23
  char   week;     // 01~07
	char   day;      // 01~
	char   month;	  // 01~12
	short  year;      // 2000~2099(00~99)
}t_RTC_TIME;



 int main(void)
 { 
	  uint16_t led_counter=0,led_flag=0,lcd_counter=0,lcd_flag=0;

	  uint8_t temp_buf[7];
	  uint32_t temperature=0;
	 
	  uint8_t voltage_buf[7];
	  uint32_t voltage=0;
	 
	  u8 Hourbuf[3];
	  u8 Minbuf[3];
	  u8 Secbuf[3];
	 	u8 datebuf[3];
	  u8 yearbuf[5];
	 
	  int8_t Sec_set=0,Min_set=0,Hour_set=0,Week_set=0,Day_set=0,Month_set=0,Year_set=0;
	 
 	  delay_init();	    	 //��ʱ������ʼ��	  
	  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2

	  Init8025();
	  KEY_Init();
		EXTIX_Init();
	  Adc_Init();
    UpdateDateTime();  
		OLED_Init();			//��ʼ��OLED
		Fill_RAM(0x00); //��ȫ��
	  Set_Contrast_Control(0x10);//������Ļ�Աȶ�
	  POWER_ON();
	  LED_ON;
		TEMP_ON;//�¶ȴ���������
		PADC_ON;//������⿪��
		
		time_set = 0;
		
	 	while(WK_UP==0)
		{
			
		}			
		
		voltage = Get_Adc_Average(13,20)*3300/0xFFF+8;
		voltage = voltage * 4+370;
			
		voltage_buf[0] = (voltage/1000%10 + 0x30);
		voltage_buf[1] = (0x2E);
    voltage_buf[2] = (voltage/100%10 + 0x30);      
    voltage_buf[3] = (voltage/10%10 + 0x30);
		voltage_buf[4] = 'V';
		voltage_buf[5] = '\0';
		voltage_buf[6] = '\0';
		Asc6_8(94,1,voltage_buf);
		temperature = Get_Adc_Average(4,20)*3300/0xFFF;
    temperature = (temperature-500)*10;			
			
		temp_buf[0] = (temperature/1000%10 + 0x30);
    temp_buf[1] = (temperature/100%10 + 0x30); 
    temp_buf[2] = (0x2E);
    temp_buf[3] = (temperature/10%10 + 0x30);
		temp_buf[4] = 'B';
		temp_buf[5] = 'C';
		temp_buf[6] = '\0';
		Asc6_8(4,1,temp_buf);
		
	  IWDG_Init(4,625);    //���Ź���ʼ��
		
    while(1)
    {
			UpdateDateTime();

      sprintf((char *)Secbuf, "%02d",stDateTime.second);
      Asc11_16(104,4,Secbuf);		
			sprintf((char *)Minbuf, "%02d",stDateTime.minute);
			Asc19_24(59,3,Minbuf);			
			sprintf((char *)Hourbuf, "%02d",stDateTime.hour);
			Asc19_24(3,3,Hourbuf);
			sprintf((char *)datebuf, "%02d",stDateTime.date);
			Asc6_8(30,7,datebuf);	
			sprintf((char *)yearbuf, "%04d",stDateTime.year+1999);
			Asc6_8(76,7,yearbuf);	
	
			week_Display(stDateTime.week);
			month_Display(stDateTime.month);
			
			Asc5_24(48,3);			

			Power_Display(voltage);
			
      Sec_set   = stDateTime.second;
			Min_set   = stDateTime.minute;
			Hour_set  = stDateTime.hour;
			Week_set  = stDateTime.week;
			Day_set   = stDateTime.date;
			Month_set = stDateTime.month;
			Year_set  = stDateTime.year;
			
			IWDG_Feed();//ι��
			
			if(KEY3==0)
		  {
			   while(KEY3==0)
				 {
					 IWDG_Feed();
				 }
			   time_set = !time_set;
		  }
      //������/////
		  while(time_set==1)
		  {
				 sprintf((char *)Secbuf, "%02d\0",Get8025_sec());
				 Asc11_16(104,4,Secbuf);
			   if(KEY2==0)
			   {	
					  Sec_set = Get8025_sec();	
            delay_ms(10);					 
				    Sec_set++;
            if(Sec_set>59){Sec_set = 0;}	
            Set8025_sec(Sec_set);							
			   }
				 if(KEY4==0)
			   {
					  Sec_set = Get8025_sec();
				    delay_ms(10);
					  Sec_set--;
            if(Sec_set<0){Sec_set = 59;}	
            Set8025_sec(Sec_set);							
			   }
			   delay_ms(100);
			   Asc11_16(104,4,"::\0");
				 IWDG_Feed();
			   delay_ms(100);

			   if(KEY3==0)
			   {
				    while(KEY3==0)
            {
						  IWDG_Feed();
						}
				    time_set++;
				    if(time_set>7)
					   time_set=0;
			   }						
		  }
      //������/////
		  while(time_set==2)
		  {
				 sprintf((char *)Secbuf, "%02d\0",Get8025_sec());
				 Asc11_16(104,4,Secbuf);
				 sprintf((char *)Minbuf, "%02d\0",Min_set);
			   Asc19_24(59,3,Minbuf);
					 
			   if(KEY2==0)
			   {		
            delay_ms(10);					 
				    Min_set++;
            if(Min_set>59){Min_set = 0;}	
            Set8025_min(Min_set);						
			   }
				 if(KEY4==0)
			   {
				    delay_ms(10);
					  Min_set--;
            if(Min_set<0){Min_set = 59;}
            Set8025_min(Min_set);							
            						
			   }
			   delay_ms(100);
			   Asc19_24(59,3,"::\0");
				 IWDG_Feed();
			   delay_ms(100);

			   if(KEY3==0)
			   {
				    while(KEY3==0)
            {
							IWDG_Feed();
						}	
						Set8025_min(Min_set);
				    time_set++;
				    if(time_set>7)
					   time_set=0;
			   }				 
		  }
      //ʱ����/////
		  while(time_set==3)
		  {
				 sprintf((char *)Secbuf, "%02d",Get8025_sec());
				 Asc11_16(104,4,Secbuf);
				 sprintf((char *)Minbuf, "%02d",Get8025_min());
			   Asc19_24(59,3,Minbuf);
				 sprintf((char *)Hourbuf, "%02d",Hour_set);
			   Asc19_24(3,3,Hourbuf);
				
			   if(KEY2==0)
			   {		
            delay_ms(10);					 
				    Hour_set++;
            if(Hour_set>23){Hour_set = 0;}	
            Set8025_hour(Hour_set);							
			   }
				 if(KEY4==0)
			   {
				    delay_ms(10);
					  Hour_set--;
            if(Hour_set<0){Hour_set = 23;}
            Set8025_hour(Hour_set);							
            						
			   }
			   delay_ms(100);
			   Asc19_24(3,3,"::\0");
				 IWDG_Feed();
			   delay_ms(100);

			   if(KEY3==0)
			   {
				    while(KEY3==0)
            {
							IWDG_Feed();
						}
					  Set8025_hour(Hour_set);
						sprintf((char *)Hourbuf, "%02d",Hour_set);
			      Asc19_24(3,3,Hourbuf);						
				    time_set++;
				    if(time_set>7)
					   time_set=0;
			   }						
		  }
      //��������/////
			while(time_set==4)
		  {
				 sprintf((char *)Secbuf, "%02d",Get8025_sec());
				 Asc11_16(104,4,Secbuf);
				 sprintf((char *)Minbuf, "%02d",Get8025_min());
			   Asc19_24(59,3,Minbuf);				
			   week_Display(Week_set);
				
			   if(KEY2==0)
			   {
					  delay_ms(10);
            Week_set++; 
            if(Week_set>7){Week_set = 1;}		
            Set8025_week(Week_set);						
			   }
				 if(KEY4==0)
			   {
					  delay_ms(10);
            Week_set--; 
            if(Week_set<1){Week_set = 7;}	
            Set8025_week(Week_set);						
			   }
			   delay_ms(100);
			   Asc6_8(4,7,"   ");	
				 IWDG_Feed();
			   delay_ms(100);

			   if(KEY3==0)
			   {				 
				    while(KEY3==0)
            {
							IWDG_Feed();
						}
					  Set8025_week(Week_set);
						week_Display(Week_set);
				    time_set++;
				    if(time_set>7)
					    time_set=0;
			   }						
		  }
      //������/////
			while(time_set==5)
		  {
				 sprintf((char *)Secbuf, "%02d",Get8025_sec());
				 Asc11_16(104,4,Secbuf);
				 sprintf((char *)Minbuf, "%02d",Get8025_min());
			   Asc19_24(59,3,Minbuf);	
				 sprintf((char *)datebuf, "%02d",Day_set);
			   Asc6_8(30,7,datebuf);	
				
			   if(KEY2==0)
			   {
					  delay_ms(10);
            Day_set++; 
            if(Day_set>31){Day_set = 1;}	
            Set8025_day(Day_set);						
			   }
				 if(KEY4==0)
			   {
					  delay_ms(10);
            Day_set--; 
            if(Day_set<1){Day_set = 31;}
            Set8025_day(Day_set);						
			   }
			   delay_ms(100);
         Asc6_8(30,7,"  ");
         IWDG_Feed();				 
			   delay_ms(100);

			   if(KEY3==0)
			   {
				    while(KEY3==0)
            {
							IWDG_Feed();
						}
					  Set8025_day(Day_set);
						sprintf((char *)datebuf, "%02d",Day_set);
			      Asc6_8(30,7,datebuf);	
				    time_set++;
				    if(time_set>7)
					    time_set=0;
			   }						
		  }
      //������/////
			while(time_set==6)
		  {
				 sprintf((char *)Secbuf, "%02d",Get8025_sec());
				 Asc11_16(104,4,Secbuf);
				 sprintf((char *)Minbuf, "%02d",Get8025_min());
			   Asc19_24(59,3,Minbuf);				
			   month_Display(Month_set);
				
			   if(KEY2==0)
			   {
					  delay_ms(10);
            Month_set++; 
            if(Month_set>12){Month_set = 1;}
            Set8025_month(Month_set);						
			   }
				 if(KEY4==0)
			   {
					  delay_ms(10);
            Month_set--; 
            if(Month_set<1){Month_set = 12;}	
            Set8025_month(Month_set);						
			   }
			   delay_ms(100);
         Asc6_8(50,7,"   ");	
         IWDG_Feed();				 
			   delay_ms(100);

			   if(KEY3==0)
			   {
				    while(KEY3==0)
            {
							IWDG_Feed();
						}
					  Set8025_month(Month_set);
						month_Display(Month_set);
				    time_set++;
				    if(time_set>7)
					    time_set=0;
			   }						
		  }
      //������/////
			while(time_set==7)
		  {
				 sprintf((char *)Secbuf, "%02d",Get8025_sec());
				 Asc11_16(104,4,Secbuf);
				 sprintf((char *)Minbuf, "%02d",Get8025_min());
			   Asc19_24(59,3,Minbuf);				
			   sprintf((char *)yearbuf, "%04d",Year_set+1999);
			   Asc6_8(76,7,yearbuf);	
			
			   if(KEY2==0)
			   {
					 	delay_ms(10);
            Year_set++; 
            if(Year_set>100){Year_set = 1;}	
            Set8025_year(Year_set);						
			   }
				 if(KEY4==0)
			   {
					 	delay_ms(10);
            Year_set--; 
            if(Year_set<1){Year_set = 100;}	
            Set8025_year(Year_set);						
			   }
			   delay_ms(100);
         Asc6_8(76,7,"    ");
				 IWDG_Feed();
			   delay_ms(100);

			   if(KEY3==0)
			   {
				    while(KEY3==0)
            {
							IWDG_Feed();
						}
						Set8025_year(Year_set);
            sprintf((char *)yearbuf, "%04d",Year_set+1999);
			      Asc6_8(76,7,yearbuf);						
				    time_set++;
				    if(time_set>7)
					    time_set=0;
			   }						
		  }
////////////////////////////////////////////////////////////////			
			if(WK_UP==0)//�ػ�
			{    		
				Fill_RAM(0x00); //��ȫ��
				delay_ms(100);//ȥ����
				IWDG_Feed();
        POWER_OFF();
				while(1)//���Ծ�
				{
					IWDG_Feed();
				}
			}
			led_counter++;
			if(led_counter >= 10)
			{
				led_counter = 0;
				if(led_flag)
				{
					LED_OFF;
					led_flag = 0;
				}
				else
		    {
			    LED_ON;
			    led_flag = 1;
		    }
			}
			//��ʱ���µ�ѹ�¶�����/////
      lcd_counter++;
      if(lcd_counter >=20)
			{
				lcd_counter = 0;
				if(lcd_flag)
				{
					lcd_flag = 0;
					temperature = Get_Adc_Average(4,20)*3300/0xFFF;
          temperature = (temperature-500)*10;			
			
			    temp_buf[0] = (temperature/1000%10 + 0x30);
          temp_buf[1] = (temperature/100%10 + 0x30); 
          temp_buf[2] = (0x2E);
          temp_buf[3] = (temperature/10%10 + 0x30);
			    temp_buf[4] = '*';
			    temp_buf[5] = 'C';
			    temp_buf[6] = '\0';
			    Asc6_8(4,1,temp_buf);
				}
	      else
				{
					lcd_flag = 1;
					voltage = Get_Adc_Average(13,20)*3300/0xFFF+8;
			    voltage = voltage * 4+370;
			
			    voltage_buf[0] = (voltage/1000%10 + 0x30);
			    voltage_buf[1] = (0x2E);
          voltage_buf[2] = (voltage/100%10 + 0x30);      
          voltage_buf[3] = (voltage/10%10 + 0x30);
			    voltage_buf[4] = 'V';
			    voltage_buf[5] = '\0';
			    voltage_buf[6] = '\0';
			    Asc6_8(94,1,voltage_buf);
				}							
      }					
    }	
}
